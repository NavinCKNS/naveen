from django.db import models
from django.urls import reverse
class students(models.Model):
    name=models.CharField(max_length=20)
    standard=models.CharField(max_length=10)
    section=models.CharField(max_length=20)
    rank=models.IntegerField()
