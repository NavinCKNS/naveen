from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import ListView,CreateView,DeleteView,UpdateView

from A1.models import students

class detail(CreateView):
    model=students
    fields=('name','standard','section','rank')
    success_url=reverse_lazy('list')
class show(ListView):
    model=students
class delete(DeleteView):
    model=students
    success_url=reverse_lazy('list')
class update(UpdateView):
    templates_name='A1/form.html'
    model=students
    fields=('standard','section','rank')
    success_url=reverse_lazy('list')

    