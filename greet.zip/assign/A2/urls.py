

from django.urls import path

from A1.views import detail,show,delete,update
from A2 import views


urlpatterns = [
    path('',views.greet),
]
