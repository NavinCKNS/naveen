from django.http import HttpResponse
from django.shortcuts import render
import datetime
 
def greet(request):
    cur=datetime.datetime.now()
    cur.hour
    if 6>= cur.hour < 12:
        return HttpResponse("Good Morning")
    elif 12 <= cur.hour < 18:
        return HttpResponse("Good Afternoon")
    else:
        return HttpResponse("Good Evening")
    
